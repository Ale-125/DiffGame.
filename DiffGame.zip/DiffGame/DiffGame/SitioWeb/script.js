// Esperar a que el DOM esté completamente cargado
document.addEventListener("DOMContentLoaded", () => {
  // Animación de intro
  const introAnimation = document.getElementById("intro-animation")
  const mainContent = document.getElementById("main-content")

  // Simular carga y mostrar el contenido principal después de la animación
  setTimeout(() => {
    introAnimation.style.animation = "introFadeOut 1s ease-out forwards"
    setTimeout(() => {
      introAnimation.style.display = "none"
      mainContent.style.display = "block"
      // Iniciar animaciones del contenido principal
      initMainContent()
    }, 1000)
  }, 5000) // 5 segundos para la animación de intro

  // Función para inicializar el contenido principal
  function initMainContent() {
    // Crear partículas para el header
    createHeaderParticles()

    // Inicializar la línea de tiempo
    initTimeline()

    // Inicializar gráficos de derivadas
    initDerivativeGraphs()

    // Inicializar pestañas de interpretación
    initInterpretationTabs()

    // Inicializar botón de volver arriba
    initScrollTopButton()

    // Inicializar modo oscuro
    initDarkMode()

    // Inicializar búsqueda
    initSearch()

    // Inicializar animaciones de scroll
    initScrollAnimations()

    // Inicializar tarjetas de reglas
    initRuleCards()

    // Inicializar tarjetas de aplicaciones
    initApplicationCards()
  }

  // Crear partículas para el header
  function createHeaderParticles() {
    const headerParticles = document.querySelector(".header-particles")
    const particleCount = 50

    for (let i = 0; i < particleCount; i++) {
      const particle = document.createElement("div")
      particle.className = "particle"

      // Estilos aleatorios para cada partícula
      const size = Math.random() * 5 + 1
      const posX = Math.random() * 100
      const posY = Math.random() * 100
      const delay = Math.random() * 5
      const duration = Math.random() * 10 + 5
      const color = getRandomNeonColor()

      particle.style.width = `${size}px`
      particle.style.height = `${size}px`
      particle.style.left = `${posX}%`
      particle.style.top = `${posY}%`
      particle.style.backgroundColor = color
      particle.style.boxShadow = `0 0 ${size * 2}px ${color}`
      particle.style.animation = `floatParticle ${duration}s ease-in-out ${delay}s infinite alternate`

      headerParticles.appendChild(particle)
    }

    // Agregar estilos CSS para la animación de partículas
    const style = document.createElement("style")
    style.textContent = `
      .particle {
        position: absolute;
        border-radius: 50%;
        pointer-events: none;
      }
      
      @keyframes floatParticle {
        0% {
          transform: translate(0, 0) rotate(0deg);
          opacity: 0.3;
        }
        100% {
          transform: translate(${Math.random() > 0.5 ? "+" : "-"}${Math.random() * 50}px, ${Math.random() > 0.5 ? "+" : "-"}${Math.random() * 50}px) rotate(${Math.random() * 360}deg);
          opacity: 0.7;
        }
      }
    `
    document.head.appendChild(style)
  }

  // Obtener un color neón aleatorio
  function getRandomNeonColor() {
    const neonColors = [
      "#00ffa3", // verde neón
      "#7c3aed", // púrpura
      "#ff2d55", // rosa
      "#0ea5e9", // azul
      "#f0abfc", // lavanda
    ]
    return neonColors[Math.floor(Math.random() * neonColors.length)]
  }

  // Inicializar la línea de tiempo
  function initTimeline() {
    const timelineEvents = document.querySelectorAll(".timeline-event")

    // Función para verificar si un elemento está en el viewport
    function isInViewport(element) {
      const rect = element.getBoundingClientRect()
      return rect.top <= (window.innerHeight || document.documentElement.clientHeight) * 0.8 && rect.bottom >= 0
    }

    // Función para verificar los elementos visibles durante el scroll
    function checkVisibility() {
      timelineEvents.forEach((event) => {
        if (isInViewport(event)) {
          event.classList.add("visible")
        }
      })
    }

    // Verificar visibilidad inicial
    checkVisibility()

    // Verificar visibilidad durante el scroll
    window.addEventListener("scroll", checkVisibility)
  }

  // Inicializar gráficos de derivadas usando Desmos
  function initDerivativeGraphs() {
    // Función para crear un gráfico Desmos
    function createGraph(elementId, expressions) {
      const element = document.getElementById(elementId)
      if (!element) return

      try {
        const calculator = Desmos.GraphingCalculator(element, {
          expressions: false,
          settingsMenu: false,
          zoomButtons: false,
          expressionsCollapsed: true,
          lockViewport: true,
          border: false,
          backgroundColor: "rgba(0, 0, 0, 0.2)",
          textColor: "#ffffff",
        })

        // Agregar expresiones
        expressions.forEach((expr) => {
          calculator.setExpression(expr)
        })

        return calculator
      } catch (error) {
        console.error("Desmos graphing calculator failed to load:", error)
        return null
      }
    }

    // Crear gráficos para cada tipo de derivada
    createGraph("graph-constant", [
      { id: "constant", latex: "y=5", color: "#00ffa3" },
      { id: "derivative", latex: "y=0", color: "#ff2d55", lineStyle: Desmos.Styles.DASHED },
    ])

    createGraph("graph-identity", [
      { id: "identity", latex: "y=x", color: "#00ffa3" },
      { id: "derivative", latex: "y=1", color: "#ff2d55", lineStyle: Desmos.Styles.DASHED },
    ])

    createGraph("graph-power", [
      { id: "power", latex: "y=x^2", color: "#00ffa3" },
      { id: "derivative", latex: "y=2x", color: "#ff2d55", lineStyle: Desmos.Styles.DASHED },
    ])

    createGraph("graph-exp", [
      { id: "exp", latex: "y=e^x", color: "#00ffa3" },
      { id: "derivative", latex: "y=e^x", color: "#ff2d55", lineStyle: Desmos.Styles.DASHED },
    ])

    createGraph("graph-log", [
      { id: "log", latex: "y=\\ln(x)", color: "#00ffa3", domain: "0.01<x<10" },
      { id: "derivative", latex: "y=1/x", color: "#ff2d55", lineStyle: Desmos.Styles.DASHED, domain: "0.01<x<10" },
    ])

    createGraph("graph-trig", [
      { id: "sin", latex: "y=\\sin(x)", color: "#00ffa3" },
      { id: "derivative", latex: "y=\\cos(x)", color: "#ff2d55", lineStyle: Desmos.Styles.DASHED },
    ])
  }

  // Inicializar pestañas de interpretación
  function initInterpretationTabs() {
    const tabs = document.querySelectorAll(".interpretation-tab")
    const contents = document.querySelectorAll(".interpretation-content")

    tabs.forEach((tab) => {
      tab.addEventListener("click", () => {
        // Remover clase activa de todas las pestañas y contenidos
        tabs.forEach((t) => t.classList.remove("active"))
        contents.forEach((c) => c.classList.remove("active"))

        // Agregar clase activa a la pestaña seleccionada
        tab.classList.add("active")

        // Mostrar el contenido correspondiente
        const tabId = tab.getAttribute("data-tab")
        const content = document.getElementById(`${tabId}-content`)
        if (content) {
          content.classList.add("active")
        }
      })
    })
  }

  // Inicializar botón de volver arriba
  function initScrollTopButton() {
    const scrollTopBtn = document.getElementById("scrollTopBtn")

    window.addEventListener("scroll", () => {
      if (window.pageYOffset > 300) {
        scrollTopBtn.classList.add("visible")
      } else {
        scrollTopBtn.classList.remove("visible")
      }
    })

    scrollTopBtn.addEventListener("click", () => {
      window.scrollTo({
        top: 0,
        behavior: "smooth",
      })
    })
  }

  // Inicializar modo oscuro
  function initDarkMode() {
    const darkModeToggle = document.getElementById("dark-mode-toggle")

    // Verificar si hay una preferencia guardada
    const isDarkMode = localStorage.getItem("darkMode") === "true"

    // Aplicar modo oscuro si está guardado
    if (isDarkMode) {
      document.body.classList.add("dark-mode")
      darkModeToggle.textContent = "☀️"
    }

    darkModeToggle.addEventListener("click", () => {
      document.body.classList.toggle("dark-mode")

      // Guardar preferencia
      const isDark = document.body.classList.contains("dark-mode")
      localStorage.setItem("darkMode", isDark)

      // Cambiar icono
      darkModeToggle.textContent = isDark ? "☀️" : "🌙"
    })
  }

  // Inicializar búsqueda
  function initSearch() {
    const searchInput = document.getElementById("site-search")
    const sections = document.querySelectorAll(".section")

    searchInput.addEventListener("input", () => {
      const searchTerm = searchInput.value.toLowerCase()

      sections.forEach((section) => {
        const sectionText = section.textContent.toLowerCase()
        const sectionId = section.id.toLowerCase()

        if (sectionText.includes(searchTerm) || sectionId.includes(searchTerm)) {
          section.style.display = "block"
        } else {
          section.style.display = "none"
        }
      })
    })
  }

  // Inicializar animaciones de scroll
  function initScrollAnimations() {
    const sections = document.querySelectorAll(".section")

    // Función para verificar si un elemento está en el viewport
    function isInViewport(element) {
      const rect = element.getBoundingClientRect()
      return rect.top <= (window.innerHeight || document.documentElement.clientHeight) * 0.8 && rect.bottom >= 0
    }

    // Función para verificar los elementos visibles durante el scroll
    function checkVisibility() {
      sections.forEach((section) => {
        if (isInViewport(section)) {
          section.classList.add("visible")
        }
      })
    }

    // Verificar visibilidad inicial
    checkVisibility()

    // Verificar visibilidad durante el scroll
    window.addEventListener("scroll", checkVisibility)
  }

  // Inicializar tarjetas de reglas
  function initRuleCards() {
    const ruleCards = document.querySelectorAll(".rule-card")

    ruleCards.forEach((card) => {
      // Agregar efecto de hover para dispositivos táctiles
      card.addEventListener("touchstart", () => {
        card.classList.add("hover")
      })

      card.addEventListener("touchend", () => {
        setTimeout(() => {
          card.classList.remove("hover")
        }, 1000)
      })
    })
  }

  // Inicializar tarjetas de aplicaciones
  function initApplicationCards() {
    const appCards = document.querySelectorAll(".application-card")

    appCards.forEach((card) => {
      card.addEventListener("mouseenter", () => {
        // Agregar efecto de brillo
        card.style.boxShadow = `0 0 20px ${getRandomNeonColor()}`
      })

      card.addEventListener("mouseleave", () => {
        // Restaurar sombra original
        card.style.boxShadow = ""
      })
    })
  }

  // Agregar efecto de navegación suave para los enlaces internos
  document.querySelectorAll('a[href^="#"]').forEach((anchor) => {
    anchor.addEventListener("click", function (e) {
      e.preventDefault()

      const targetId = this.getAttribute("href")
      const targetElement = document.querySelector(targetId)

      if (targetElement) {
        window.scrollTo({
          top: targetElement.offsetTop - 100,
          behavior: "smooth",
        })

        // Actualizar URL sin recargar la página
        history.pushState(null, null, targetId)
      }
    })
  })

  // Agregar efecto de resaltado para enlaces de navegación activos
  function updateActiveNavLink() {
    const sections = document.querySelectorAll(".section")
    const navLinks = document.querySelectorAll(".nav-link")

    let currentSection = ""

    sections.forEach((section) => {
      const sectionTop = section.offsetTop
      const sectionHeight = section.clientHeight

      if (window.pageYOffset >= sectionTop - 200 && window.pageYOffset < sectionTop + sectionHeight - 200) {
        currentSection = "#" + section.id
      }
    })

    navLinks.forEach((link) => {
      link.classList.remove("active")
      if (link.getAttribute("href") === currentSection) {
        link.classList.add("active")
      }
    })
  }

  // Actualizar enlaces activos durante el scroll
  window.addEventListener("scroll", updateActiveNavLink)

  // Inicializar efectos de partículas matemáticas
  function initMathParticles() {
    const mathSymbols = ["∫", "∑", "∂", "∞", "√", "π", "θ", "Δ", "∇", "λ", "μ", "σ", "Ω"]
    const body = document.body

    // Crear contenedor de partículas
    const mathRain = document.createElement("div")
    mathRain.className = "math-rain"
    body.appendChild(mathRain)

    // Crear partículas
    for (let i = 0; i < 30; i++) {
      createMathParticle()
    }

    function createMathParticle() {
      const particle = document.createElement("div")
      particle.className = "math-symbol"

      // Configuración aleatoria
      const symbol = mathSymbols[Math.floor(Math.random() * mathSymbols.length)]
      const posX = Math.random() * 100
      const particleDelay = Math.random() * 10
      const particleDuration = Math.random() * 20 + 10
      const size = Math.random() * 20 + 10
      const color = getRandomNeonColor()

      // Aplicar estilos
      particle.textContent = symbol
      particle.style.left = `${posX}%`
      particle.style.top = "-50px"
      particle.style.fontSize = `${size}px`
      particle.style.color = color
      particle.style.opacity = "0"
      particle.style.animationDelay = `${particleDelay}s`
      particle.style.animationDuration = `${particleDuration}s`

      mathRain.appendChild(particle)

      // Eliminar partícula después de la animación
      setTimeout(() => {
        particle.remove()
        createMathParticle()
      }, particleDuration * 1000)
    }

    // Agregar estilos CSS para las partículas matemáticas
    const style = document.createElement("style")
    style.textContent = `
      .math-symbol {
        position: absolute;
        animation: mathFall linear forwards;
        pointer-events: none;
      }
      
      @keyframes mathFall {
        0% {
          transform: translateY(0) rotate(0deg);
          opacity: 0;
        }
        10% {
          opacity: 0.7;
        }
        90% {
          opacity: 0.7;
        }
        100% {
          transform: translateY(100vh) rotate(360deg);
          opacity: 0;
        }
      }
    `
    document.head.appendChild(style)
  }

  // Iniciar partículas matemáticas
  initMathParticles()

  // Agregar manejador de eventos para los enlaces de navegación
  const navLinks = document.querySelectorAll('.nav-link');
  navLinks.forEach(link => {
    link.addEventListener('click', (e) => {
      e.preventDefault();
      const targetId = link.getAttribute('href').substring(1);
      const targetElement = document.getElementById(targetId);
      if (targetElement) {
        targetElement.scrollIntoView({
          behavior: 'smooth',
          block: 'start'
        });
      }
    });
  });

  // Mobile Menu Functionality
  const mobileMenuBtn = document.querySelector('.mobile-menu-btn');
  const navContainer = document.querySelector('.nav-container');
  const navLinks = document.querySelectorAll('.nav-link');

  mobileMenuBtn.addEventListener('click', () => {
    navContainer.classList.toggle('active');
    mobileMenuBtn.classList.toggle('active');
  });

  // Close mobile menu when clicking a link
  navLinks.forEach(link => {
    link.addEventListener('click', () => {
      navContainer.classList.remove('active');
      mobileMenuBtn.classList.remove('active');
    });
  });

  // Close mobile menu when clicking outside
  document.addEventListener('click', (e) => {
    if (!navContainer.contains(e.target) && !mobileMenuBtn.contains(e.target)) {
      navContainer.classList.remove('active');
      mobileMenuBtn.classList.remove('active');
    }
  });

  // Prevent body scroll when mobile menu is open
  function toggleBodyScroll(disable) {
    document.body.style.overflow = disable ? 'hidden' : '';
  }

  mobileMenuBtn.addEventListener('click', () => {
    toggleBodyScroll(navContainer.classList.contains('active'));
  });
})

